<?php

use RedBeanPHP\Facade as R;

/*
 * READ
 */

/*
 * @TODO checker ce qu'est verification number et valid cost
 */

function json_encode_token($data) {
    //$data['token'] = generateToken($_SESSION['id']);
    $json=json_encode($data);
    return $json;
}

function checkToken($token, $time) {
    $limit = time() - $time;
    $t = R::exportAll(R::find('tokens', 'token = ? AND time > ?', [$token, $limit]));
    if (sizeof($t) == 0) {
        return false;
    } else {
        $user = readVisitorById($t[0]['employee_id']);
        $_SESSION['label'] = $user[0]['label'];
        $_SESSION['id'] = $user[0]['id'];
        return true;
    }
}

function removeTokens($empId) {
    $tokens = R::findAll('tokens', 'employee_id = ?', [$empId]);
    R::trashAll($tokens);
}

function getToken($empId, $time) {
    $limit = time() - $time;
    $token = R::find('tokens', 'employee_id = ? AND time > ?', [$empId, $limit]);

    return R::exportAll($token)[0]['token'];
}

function hasToken($empId, $time) {
    $limit = time() - $time;
    $token = R::find('tokens', 'employee_id = ? AND time > ?', [$empId, $limit]);
    if (sizeof($token) == 0) {
        return false;
    } else {
        return true;
    }
}

function generateToken($userId) {
    removeTokens($userId);
    $tokens = R::dispense('tokens');
    $tokens->employee_id = $userId;
    $token = openssl_random_pseudo_bytes(16);
    $token = bin2hex($token);
    $tokens->token = $token;
    $tokens->time = time();
    $tokens->count = 1;
    R::store($tokens);
    return $token;
}

function createCostSheet($idVisitor, $date) {
    $costSheet = R::dispense('costsheet');
    $costSheet->visitor_id = $idVisitor;
    $costSheet->status = 1;
    $costSheet->date = $date;
    R::store($costSheet);
    return json_encode(R::exportAll($costSheet));
}

function createPackageLine($month, $quantity, $packageCostId, $costSheetId) {
    $packageLine = R::dispense('packageline');
    $packageLine->month = $month;
    $packageLine->quantity = $quantity;
    $packageLine->package_cost_id = $packageCostId;
    $packageLine->cost_sheet_id = $costSheetId;
    R::store($packageLine);
    return json_encode(R::exportAll($packageLine));
}

function createOutPackageLine($date, $cost, $label, $costSheetId) {
    $outPackageLine = R::dispense('outPackageLine');
    $outPackageLine->date = $date;
    $outPackageLine->cost = $cost;
    $outPackageLine->label = $label;
    $outPackageLine->cost_sheet_id = $costSheetId;
    R::store($outPackageLine);
    return json_encode(R::exportAll($outPackageLine));
}

function createPackageCost($label, $cost) {
    $packageCost = R::dispense('packageCost');
    $packageCost->label = $label;
    $packageCost->cost = $cost;
    return json_encode(R::exportAll($packageCost));
}

/*
 * READ
 */

function readCostSheetsByMonth($month) {
    $costSheets = R::find('costsheet', 'month = ?', [$month]);
    return json_encode(R::exportAll($costSheets));
}

function readCostSheetsByMonthVisitor($month, $matricule) {
    $costSheets = R::find('costsheet', 'month(date) = ? AND visitor_id= ?', [$month, $matricule]);
    return json_encode_token(R::exportAll($costSheets));
}

function readVisitorById($id) {
    $visitor = R::getAll('select visitor.id, name, first_name, location, city, postal_code, label '
                    . 'from visitor, job where visitor.job_id = job.id and visitor.id=?', [$id]);
    return R::exportAll(R::convertToBeans('visitor',$visitor));
}

function readAuth($login, $password) {
    $auth = R::getAll('select visitor.id, name, first_name, location, city, postal_code, label '
                    . 'from visitor, job where visitor.job_id = job.id and login = ? '
                    . 'and password = ?', [$login, $password]);
    return json_encode(R::exportAll(R::convertToBeans('auth', $auth)));
}

function readCostSheetsByVisitor($matricule) {
    $costSheets = R::find('costsheet', 'visitor_id= ?', [$matricule]);
    return json_encode(R::exportAll($costSheets));
}

function readPackageCost() {
    $packageCost = R::findAll('packagecost', 'ORDER BY label');
    return json_encode(R::exportAll($packageCost));
}

function readCostSheetByStatus($status) {
    $costSheets = R::find('costsheet', 'status_id=?', [$status]);
    return json_encode(R::exportAll($costSheets));
}

function readPackageLineByCostSheet($costSheet) {
    $packageLine = R::find('packageline', 'cost_sheet_id=?', [$costSheet]);
    return json_encode(R::exportAll($packageLine));
}

function readOutPackageLineByCostSheet($costSheet) {
    $outPackageLine = R::find('outpackageline', 'cost_sheet_id=?', [$costSheet]);

    return json_encode(R::exportAll($outPackageLine));
}

function readOutPackageLineByVisitorIdAndMonth($id, $month) {
    $outPackageLine = R::getAll('SELECT visitor.id,outpackageline.label, outpackageline.cost FROM outpackageline, costsheet, visitor '
                    . 'where visitor.id = costsheet.visitor_id and outpackageline.cost_sheet_id = costsheet.id '
                    . 'and visitor.id = ? and month(outpackageline.date) = ?', [$id, $month]);

    return json_encode($outPackageLine);
}

function readPackageLineByVisitorIdAndMonth($id, $month) {
    $outPackageLine = R::getAll('SELECT visitor.id,packagecost.label, packagecost.cost, packageline.quantity FROM packagecost, packageline, costsheet, visitor '
                    . 'where visitor.id = costsheet.visitor_id and packageline.cost_sheet_id = costsheet.id and packagecost.id = packageline.package_cost_id '
                    . 'and visitor.id = ? and month(packageline.date) = ?', [$id, $month]);

    return json_encode($outPackageLine);
}

/*
 * UPDATE
 * @TODO changer la date lors de la modif
 */

function updateCostSheetStatus($status, $idCostSheet) {
    $costSheet = R::load('costsheet', $idCostSheet);
    $costSheet->status_id = $status;
    R::store($costSheet);
    return json_encode(R::exportAll($costSheet));
}

function updateCostSheet($idCostSheet, $justificationNumber, $validCost) {
    $costSheet = R::load('costsheet', $idCostSheet);
    $costSheet->justification_number = $justificationNumber;
    $costSheet->valid_cost = $validCost;
    R::store($costSheet);
    return json_encode(R::exportAll($costSheet));
}

function updateOutPackageLine($id, $cost, $label) {
    $outPackageLine = R::load('outpackageline', $id);
    $outPackageLine->cost = $cost;
    $outPackageLine->label = $label;
    R::store($outPackageLine);
    return json_encode(R::exportAll($outPackageLine));
}

function updatePackageLine($id, $quantity, $packageCostId) {
    $packageLine = R::load('packageline', $id);
    $packageLine->quantity = $quantity;
    $packageLine->package_cost_id = $packageCostId;
    R::store($packageLine);
    return json_encode(R::exportAll($packageLine));
}

function updatePackageCost($id, $cost, $label) {
    $packageCost = R::load('packagecost', $id);
    $packageCost->cost = $cost;
    $packageCost->label = $label;
    R::store($packageCost);
    return json_encode(R::exportAll($packageCost));
}

/*
 * DELETE
 */

function deleteCostSheetYear($month) {
    $costSheets = R::find('costsheet', 'month=?', [$month]);
    R::trashAll($costSheets);
}

function deleteOutPackageLine($costSheetId) {
    $outPackageLine = R::find('outpackageline', 'cost_sheet_id=?', [$costSheetId]);
    R::trashAll($outPackageLine);
}

function deletePackageLine($costSheetId) {
    $packageLine = R::find('packageline', 'cost_sheet_id=?', [$costSheetId]);
    R::trashAll($packageLine);
}

function deletePackageCost($id) {
    $packageCost = R::find('packagecost', 'id=?', [$id]);
    R::trashAll($packageCost);
}
