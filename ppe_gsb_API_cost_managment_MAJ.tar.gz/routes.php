<?php

//COSTSHEETMANAGMENT

session_start();

$app->get('/', function() {
})->name('home');

$authenticateForRole = function ( $roles = array('Visiteur') ) {
    return function () use ( $roles ) {
        /*unset($_SESSION);
        //if (isset($_POST['token'])) {
        checkToken('31a4dac97e7f6ca9d52bb9d72b288274', '1200'); //@TODO a mettre le $_POST['token']
        //checkToken($_POST['token'], '1200');
        //}
        
        if (!isset($_SESSION['label'])) {
            $app = \Slim\Slim::getInstance();
            $app->redirectTo('home');
        } else {
            if (!in_array($_SESSION['label'], $roles)) {
                $app = \Slim\Slim::getInstance();
                $app->redirectTo('home');
            }
        }*/
    };
};

/*
 * CREATE
 */

//CREATE A COST SHEET
$app->get('/create/costsheet/visitor/:id/:month', $authenticateForRole(array('Visiteur')), function($id,$date) {
    echo createCostSheet($id, $date);
});

//CREATE DE PACKAGELINE
$app->get('/create/packageLine/:month/:quantity/:packageCostId/:costSheetId', $authenticateForRole(array('Visiteur')), function($month, $quantity, $packageCostId, $costSheetId) {
    echo createPackageLine($month, $quantity, $packageCostId, $costSheetId);
});

//CREATE AN OUTPACKAGE LINE
$app->get('/create/outPackageLine/:date/:cost/:label/:costSheetId', $authenticateForRole(array('Visiteur')), function($date, $cost, $label, $costSheetId) {
    echo createOutPackageLine($date, $cost, $label, $costSheetId);
});

//CREATE A PACKAGECOST
$app->get('/create/packageCost/:label/:cost', $authenticateForRole(array('Comptable')), function($label, $cost) {
    echo createPackageCost($label, $cost);
});

/*
 * READ
 */

//VISITOR BY MATRICULE @TODO appel a l'API RH
$app->get('/visitor/:id', $authenticateForRole(array('Comptable')), function($id) {
    
});

//ALL COST SHEET BY MONTH
$app->get('/costSheet/month/:month', $authenticateForRole(array('Comptable')), function($month) {
    echo readCostSheetsByMonth($month);
});

//COST SHEET BY VISITOR & BY MONTH
$app->get('/costSheet/visitor/:id/month/:month', $authenticateForRole(array('Visiteur', 'Comptable')), function($month,$id) {
    echo readCostSheetsByMonthVisitor($month, $id);
});

//ALL COST SHEET FOR ONE VISITOR
$app->get('/costSheet/visitor/:id', $authenticateForRole(array('Visiteur', 'Comptable')), function($id) {
    echo readCostSheetsByVisitor($id);
});

$app->get('/auth/:login/:password', function($login, $password) {
    $user = readAuth($login, $password);
    $userTable = json_decode($user, true);
    if (!empty($userTable)) {
        if (!hasToken($userTable[0]['id'], '1200')) {
            removeTokens($userTable[0]['id']);
            $token = generateToken($userTable[0]['id']);
            $userTable[0]['token'] = $token;
        } else {
            $userTable[0]['token'] = getToken($userTable[0]['id'], '1200');
        }
    }
    $userJSON = json_encode($userTable);

    echo $userJSON;
});

$app->get('/visitor/:id', $authenticateForRole(array('Comptable')), function($id) {
    echo readVisitorById($id);
});

//ALL PACKAGE COST
$app->get('/costSheet/packageCost', $authenticateForRole(array('Visiteur', 'Comptable')), function() {
    echo readPackageCost();
});

//ALL COST SHEET BY STATUS
$app->get('/costSheet/Status/:status', $authenticateForRole(array('Visiteur', 'Comptable')), function($status) {
    echo readCostSheetByStatus($status);
});

//ALL PACKAGE LINE FROM A COST SHEET
$app->get('/packageLine/:costSheetId', $authenticateForRole(array('Visiteur', 'Comptable')), function($costSheetId) {
    echo readPackageLineByCostSheet($costSheetId);
});

//ALL OUT PACKAGE LINE FROM A COST SHEET
$app->get('/outPackageLine/:costSheetId', $authenticateForRole(array('Visiteur', 'Comptable')), function($costSheetId) {
    echo readOutPackageLineByCostSheet($costSheetId);
});

$app->get('/outPackageLine/visitor/:id/month/:month', $authenticateForRole(array('Visiteur', 'Comptable')), function($id,$month) {
    echo readOutPackageLineByVisitorIdAndMonth($id, $month);
});

$app->get('/packageLine/visitor/:id/month/:month', $authenticateForRole(array('Visiteur', 'Comptable')), function($id,$month) {
    echo readPackageLineByVisitorIdAndMonth($id, $month);
});

/*
 * UPDATE
 */

//UPDATE COST SHEET STATUS
$app->get('/update/costSheet/status/:status/idCostSheet/:idCostSheet', $authenticateForRole(array('Visiteur', 'Comptable')), function($status, $idCostSheet) {
    echo updateCostSheetStatus($status, $idCostSheet);
});

//UPDATE A COST SHEET
$app->get('/update/costsheet/:id/:justificationNumber/:validCost', function($id, $justificationNumber, $validCost) {
    echo updateCostSheet($id, $justificationNumber, $validCost);
});

//UPDATE AN OUTPACKAGE LINE
$app->get('/update/outpackageLine/:id/:cost/:label', $authenticateForRole(array('Visiteur', 'Comptable')), function($id, $cost, $label) {
    echo updateOutPackageLine($id, $cost, $label);
});

//UPDATE A PACKAGE LINE
$app->get('/update/packageLine/:id/:quantity/:packageCostId', $authenticateForRole(array('Visiteur', 'Comptable')), function($id, $quantity, $packageCostId) {
    echo updatePackageLine($id, $quantity, $packageCostId);
});

//UPDATE A PACKAGE COST
$app->get('/update/packageCost/:id/:cost/:label', $authenticateForRole(array('Comptable')), function($id, $cost, $label) {
    echo updatePackageCost($id, $cost, $label);
});

/*
 * DELETE
 */

//DELETE ALL COSTSHEET OLDER THAN A YEAR
$app->get('/delete/costSheet/month/:month', $authenticateForRole(array('Comptable')), function($month) {
    deleteCostSheetYear($month);
});

//DELETE OUTPACKAGE LINE FROM A COSTSHEET
$app->get('/delete/outpackageLine/costSheetId/:costSheetId', $authenticateForRole(array('Comptable')), function($costSheetId) {
    deleteOutPackageLine($costSheetId);
});

//DELETE PACKAGE LINE FROM A COSTSHEET
$app->get('/delete/packageLine/costSheetId/:costSheetId', $authenticateForRole(array('Visiteur', 'Comptable')), function($costSheetId) {
    deletePackageLine($costSheetId);
});


//DELETE ALL LINES FROM A COSTSHEET
$app->get('/delete/Line/costSheetId/:costSheetId', $authenticateForRole(array('Comptable')), function($costSheetId) {
    deleteOutPackageLine($costSheetId);
    deletePackageLine($costSheetId);
});

//DELETE A PACKAGE COST
$app->get('/delete/packageCost/:id', $authenticateForRole(array('Comptable')), function($id) {
    deletePackageCost($id);
});
